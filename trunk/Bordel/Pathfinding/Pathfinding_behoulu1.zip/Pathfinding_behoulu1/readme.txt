- aplikace je naps�na v ms visual studiu 2008 v jazyce C#
- ke spu�t�n� je pot�eba .NET framework 2.0 nebo vy���
  http://www.microsoft.com/downloads/en/details.aspx?FamilyId=333325fd-ae52-4e35-b531-508d977d32a6&displaylang=en
